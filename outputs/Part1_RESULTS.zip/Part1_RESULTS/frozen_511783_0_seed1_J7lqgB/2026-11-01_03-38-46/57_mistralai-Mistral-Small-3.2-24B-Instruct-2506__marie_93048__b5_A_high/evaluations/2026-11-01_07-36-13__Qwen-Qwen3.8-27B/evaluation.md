# Evaluation · Marie · A high

| | |
|---|---|
| **Run** | `57_mistralai-Mistral-Small-3.2-24B-Instruct-2506__marie_93048__b5_A_high` |
| **Speaker** | mistralai/Mistral-Small-3.2-24B-Instruct-2506 |
| **Judge** | Qwen/Qwen3.8-27B · temperature 0.0 · seed 42 |
| **Status** | completed · 5/5 judge calls valid |

## Summary

| Measure | Result |
|---|---|
| Disclosure: directly relevant | **13/15** (87%) |
| Disclosure: related background | 5/10 (50%) |
| Contradictions | **0** in 0/16 assessed turns |
| Unsupported additions | **20** in 12/16 assessed turns · 1 could change care |
| Spoken naturalness | **3**/5 |
| Conversational fit | **4**/5 |
| Lexical diversity (MATTR-50) | 0.827 |
| Mean words per reply | 68.2 |

<sub>Disclosure counts each supplied fact on each turn it was assigned. Background facts are optional. Finding counts cover fully assessed turns only. No combined score is calculated.</sub>

## Communication behaviors

| Behavior / subtype | Turns | Where |
|---|---|---|
| affect | 7/16 | 1, 3, 4, 5, 12, 13, 15 |
| affect / worry | 2/16 | 1, 15 |
| affect / distress | 5/16 | 3, 4, 5, 12, 13 |
| affect / embarrassment | 0/16 | - |
| affect / calm optimism | 1/16 | 13 |
| patient question | 1/16 | 15 |
| patient question / reassurance | 0/16 | - |
| patient question / explanation | 1/16 | 15 |
| patient question / practical | 0/16 | - |
| interaction stance | 2/16 | 15, 16 |
| interaction stance / appreciation | 2/16 | 15, 16 |
| interaction stance / reservation | 0/16 | - |
| interaction stance / challenge | 0/16 | - |
| own interpretation | 2/16 | 2, 14 |
| unasked content | 10/16 | 1, 5, 6, 9, 10, 11, 12, 13, 14, 16 |
| reporting style | 2/16 | 7, 8 |
| reporting style / organizing clarifying | 1/16 | 8 |
| reporting style / difficulty recounting | 1/16 | 7 |
| care engagement | 0/16 | - |
| care engagement / proactive | 0/16 | - |
| care engagement / avoidant | 0/16 | - |

Counts are turns, not phrases. Categories/subtypes can overlap; category totals count each turn once. Incomplete annotation turns are excluded from denominators. Other observations are uncounted pilot notes.

## Realism

**Spoken naturalness: 3/5**

> "It's not something I've consciously noticed until others started mentioning it." (turn 1)

The patient's speech is consistently articulate, grammatically perfect, and structurally complex, which is less typical of spontaneous patient dialogue. The language often feels like a written report or a scripted response rather than natural speech. For example, in turn 1, the phrase 'It's not something I've consciously noticed until others started mentioning it' is overly formal and precise for a casual conversation. Similarly, in turn 3, the use of 'lymph nodes' is a specific medical term that a layperson might not use spontaneously without prompting, and the sentence structure 'It's been a bit uncomfortable, especially when I'm lying down or trying to sleep' is very polished. The lack of fillers, hesitations, or self-corrections across all turns contributes to a mechanical, assistant-like quality that reduces the realism of the spoken naturalness. Context: turn 1.

**Conversational fit: 4/5**

> "My son and his family live in Munich, and they had their second child last month." (turn 13)

The patient's responses are generally well-connected to the doctor's questions and flow logically. However, there are occasional instances where the patient provides more detail than strictly necessary or shifts focus slightly. In turn 13, when asked if there is anything else going on in life, the patient mentions their son's new baby and their Italian class. While this is relevant to 'life,' the transition from discussing physical symptoms to personal family news and hobbies is a bit abrupt and feels like a list of unrelated facts rather than a natural conversational flow. Additionally, in turn 16, the patient introduces new symptoms (trouble sleeping, night sweats) at the very end, which, while realistic for a patient who might forget things, feels slightly disjointed from the previous comprehensive review of symptoms. Overall, the conversational fit is good, but these minor shifts in focus and the late introduction of new information prevent a perfect score. Context: turn 13.

## Turn by turn

Legend: ✓ disclosed · ✗ not disclosed · ? unassessed · *(bg)* related background

---

### Turn 1

**Doctor:** Hello Marie, I see you've come in because of some redness in your eyes. Can you tell me a bit about that?

**Patient:** Well, yes, doctor. It's been a bit concerning. I've noticed that both of my eyes have been quite red lately. My husband, Thomas, was actually the first to point it out. He mentioned that they looked a bit inflamed. And at work, my colleagues have been asking if I've been crying because of how red they are. It's not something I've consciously noticed until others started mentioning it.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | M10 | I have noticed widespread redness in both eyes. | "I've noticed that both of my eyes have been quite red lately." |
| ✓ | L6 *(bg)* | My husband Thomas was the first to notice my eyes looked red. | "My husband, Thomas, was actually the first to point it out." |
| ✓ | L7 *(bg)* | My colleagues at work kept asking whether I'd been crying. | "my colleagues have been asking if I've been crying" |

**Findings:** none.

**Behaviors**

- `t01_affect_worry` **affect / worry** – The patient explicitly labels the situation as concerning, adding an emotional frame to the factual report.
  > "It's been a bit concerning."
- `t01_unasked_content` **unasked content** – The patient adds a specific detail about the appearance of the eyes ('inflamed') and a subjective timeline ('not consciously noticed') that goes beyond the core facts of redness and who noticed it.
  > "He mentioned that they looked a bit inflamed." · "It's not something I've consciously noticed until others started mentioning it."

**Linguistic notes:** none.

---

### Turn 2

**Doctor:** Is there anything else you've noticed about your health lately?

**Patient:** Oh, yes, I've been feeling quite short of breath lately. It's like I can't get enough air sometimes. It's been happening more often, especially when I'm at work or trying to do some chores around the house. I've also been having some pain in my hands, which is making it a bit difficult to do things. I'm not sure if it's related, but it's been quite uncomfortable.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | M8 | I am short of breath and have real difficulty breathing. | "I've been feeling quite short of breath lately." |
| ✓ | M3 *(bg)* | I have pain in both my hands. | "I've also been having some pain in my hands" |

**Findings**

- **Unsupported addition** · medical · *could change interpretation*
  > "It's been happening more often, especially when I'm at work or trying to do some chores around the house."

  The script fact states shortness of breath and difficulty breathing, but does not specify triggers (work/chores) or a progressive frequency. Adding specific exertional triggers is an unscripted clinical detail.

**Behaviors**

- `t02_own_interpretation` **own interpretation** – The patient offers a hypothesis about the relationship between the two symptoms, suggesting they might be connected.
  > "I'm not sure if it's related"

**Linguistic notes:** none.

---

### Turn 3

**Doctor:** Have you noticed any swollen or painful glands?

**Patient:** Oh, yes, doctor. I've noticed that my lymph nodes have been swollen and painful. It's mostly around my neck and under my arms. I first noticed it a few weeks ago. It's been a bit uncomfortable, especially when I'm lying down or trying to sleep. I'm not sure what could be causing it, but it's been quite bothersome.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | M0 | My lymph nodes are swollen and painful. | "I've noticed that my lymph nodes have been swollen and painful." |

**Findings**

- **Unsupported addition** · medical · *could change interpretation*
  > "It's mostly around my neck and under my arms."

  The script fact only states that lymph nodes are swollen and painful, without specifying location. Specifying cervical and axillary nodes adds unscripted clinical detail.
- **Unsupported addition** · medical · *minor context*
  > "I first noticed it a few weeks ago."

  The script does not provide a timeline for the onset of lymph node swelling. Adding 'a few weeks ago' is an unscripted temporal detail.
- **Unsupported addition** · medical · *could change interpretation*
  > "especially when I'm lying down or trying to sleep"

  The script does not mention specific aggravating factors for the lymph node pain. Adding positional triggers is an unscripted clinical detail.

**Behaviors**

- `t03_affect_distress` **affect / distress** – The patient expresses that the symptom is bothersome, indicating a level of discomfort or frustration.
  > "it's been quite bothersome."

**Linguistic notes:** none.

---

### Turn 4

**Doctor:** Have you had any pain anywhere? Where is it, what does it feel like, and how bad is it on a scale from zero to ten?

**Patient:** Yes, I've been having some pain in both of my hands. It's a bit difficult to describe, but it feels tender, burning, and sharp at times. The pain is quite intense, I'd say about an 8 out of 10. It's been making it hard to type at work and even to do simple tasks at home. I'm not sure what's causing it, but it's been quite debilitating.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | M2 | The pain in both my hands feels tender, burning, and sharp. | "it feels tender, burning, and sharp at times" |
| ✓ | M3 | I have pain in both my hands. | "I've been having some pain in both of my hands." |
| ✓ | M4 | The pain in both my hands is about 8 out of 10. | "I'd say about an 8 out of 10." |
| ✗ | M5 *(bg)* | The pain in both my hands doesn't spread anywhere else. | – |
| ✗ | L0 *(bg)* | I work as a secretary at a law firm. | – |

**Findings**

- **Unsupported addition** · medical · *minor context*
  > "It's been making it hard to type at work and even to do simple tasks at home."

  The script does not specify functional limitations caused by the hand pain. Adding specific activities (typing, simple tasks) is an unscripted detail about impact.

**Behaviors**

- `t04_affect_distress` **affect / distress** – The patient uses the word 'debilitating' to describe the impact of the pain, expressing a sense of being overwhelmed or significantly hindered.
  > "it's been quite debilitating."

**Linguistic notes:** none.

---

### Turn 5

**Doctor:** And how about your weight?

**Patient:** Well, I have been struggling with my weight for some time now. I'm significantly overweight for my height. It's something I've been trying to manage, but it's been a challenge. I've tried different diets and even joined a gym a few years back, but it's hard to keep up with everything. I know it's not ideal, but I'm doing my best.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | M9 | I am significantly overweight for my height. | "I'm significantly overweight for my height." |
| ✗ | M8 *(bg)* | I am short of breath and have real difficulty breathing. | – |

**Findings**

- **Unsupported addition** · non-medical · *minor context*
  > "I've tried different diets and even joined a gym a few years back"

  The patient invents a history of dieting and gym membership that is not present in the script facts.

**Behaviors**

- `t05_affect_distress` **affect / distress** – The patient expresses frustration and a sense of being overwhelmed by the difficulty of managing their weight.
  > "it's been a challenge" · "I know it's not ideal"
- `t05_unasked_content` **unasked content** – The patient provides unasked details about past lifestyle interventions (diets, gym) beyond the simple confirmation of being overweight.
  > "I've tried different diets and even joined a gym a few years back"

**Linguistic notes:** none.

---

### Turn 6

**Doctor:** Have you been abroad at all in the last few weeks?

**Patient:** No, doctor, I haven't traveled outside the country in the last four weeks. I've mostly been at home or at work. I did go to the park with my husband last weekend, but that's about it.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | M12 | I have not travelled outside the country in the last four weeks. | "I haven't traveled outside the country in the last four weeks." |

**Findings**

- **Unsupported addition** · non-medical · *minor context*
  > "I did go to the park with my husband last weekend"

  The patient invents a specific recent activity (going to the park) that is not in the script facts.

**Behaviors**

- `t06_unasked_content` **unasked content** – The patient adds unasked details about their recent activities at home and in the park.
  > "I've mostly been at home or at work" · "I did go to the park with my husband last weekend"

**Linguistic notes:** none.

---

### Turn 7

**Doctor:** And the pain, did it come on suddenly or more gradually?

**Patient:** Oh, the pain in both my hands came on very gradually. I don't remember a specific moment when it started. It's just been getting worse over time. At first, it was just a slight discomfort, but now it's become quite intense.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | M7 | The pain in both my hands came on very gradually. | "the pain in both my hands came on very gradually" |
| ✗ | M6 *(bg)* | I cannot pinpoint the pain in both my hands; it covers a wide area. | – |

**Findings:** none.

**Behaviors**

- `t07_reporting_style_difficulty_recounting` **reporting style / difficulty recounting** – The patient explicitly states they cannot recall the specific onset moment of the pain.
  > "I don't remember a specific moment when it started"

**Linguistic notes:** none.

---

### Turn 8

**Doctor:** And roughly how long has all this been going on?

**Patient:** Oh, I'd say it's been about three months now. The pain in my hands started a bit earlier than the redness in my eyes and the swollen glands. But it's all been quite gradual, and I've been trying to manage it on my own until now.

**Supplied statements:** none.

**Findings**

- **Unsupported addition** · medical · *could change interpretation*
  > "it's been about three months now"

  The patient invents a specific duration for the symptoms that is not provided in the script facts.
- **Unsupported addition** · medical · *could change interpretation*
  > "The pain in my hands started a bit earlier than the redness in my eyes and the swollen glands"

  The patient invents a specific chronological order of symptom onset that is not in the script facts.

**Behaviors**

- `t08_reporting_style_organizing_clarifying` **reporting style / organizing clarifying** – The patient actively sequences the onset of different symptoms to clarify the timeline.
  > "The pain in my hands started a bit earlier than the redness in my eyes and the swollen glands"

**Linguistic notes:** none.

---

### Turn 9

**Doctor:** Do you have any long-term health conditions?

**Patient:** No, I don't have any long-term health conditions. I've always been relatively healthy, aside from the usual colds and flus. I do have a family history of diabetes and heart disease, but I haven't been diagnosed with anything myself. I try to take care of myself, but I know I could do better with my diet and exercise.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | X2 | No, I don't have any long-term health conditions. | "No, I don't have any long-term health conditions." |

**Findings**

- **Unsupported addition** · medical · *could change interpretation*
  > "I do have a family history of diabetes and heart disease"

  The patient invents a specific family medical history not present in the script facts.

**Behaviors**

- `t09_unasked_content` **unasked content** – The patient volunteers details about family history and self-care habits that were not requested by the doctor's specific question about long-term conditions.
  > "I do have a family history of diabetes and heart disease" · "I try to take care of myself, but I know I could do better with my diet and exercise."

**Linguistic notes:** none.

---

### Turn 10

**Doctor:** Can you tell me a bit about your lifestyle, things like smoking or drinking?

**Patient:** Well, I don't smoke cigarettes, but I do enjoy a glass of wine in the evening. It's sort of a way to unwind after a long day. I usually have one or two glasses, nothing too excessive. I've never been much of a drinker, so that's about the extent of it. As for exercise, I try to go for walks when I can, but it's not as often as I'd like. I do enjoy gardening, though. It's a bit of a hobby of mine.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | X0 | I don't smoke cigarettes. | "I don't smoke cigarettes" |

**Findings**

- **Unsupported addition** · non-medical · *minor context*
  > "I do enjoy a glass of wine in the evening"

  The patient invents specific drinking habits and quantities not present in the script facts for this turn.
- **Unsupported addition** · non-medical · *minor context*
  > "I try to go for walks when I can"

  The patient invents exercise habits not present in the script facts.
- **Unsupported addition** · non-medical · *minor context*
  > "I do enjoy gardening, though. It's a bit of a hobby of mine."

  The patient invents a hobby not present in the script facts.

**Behaviors**

- `t10_unasked_content` **unasked content** – The patient provides extensive detail about alcohol consumption, exercise, and hobbies beyond the simple confirmation of non-smoking.
  > "I do enjoy a glass of wine in the evening" · "I try to go for walks when I can" · "I do enjoy gardening, though."

**Linguistic notes:** none.

---

### Turn 11

**Doctor:** And how much alcohol do you drink in a typical week?

**Patient:** Oh, I'd say I have about three or four glasses of wine a week. It's usually just in the evenings, nothing during the day. I don't really drink any other alcoholic beverages. I've never been much of a beer or spirits person. It's just the wine that I enjoy.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | X1 | I don't drink a lot of alcohol. | "I'd say I have about three or four glasses of wine a week" |

**Findings**

- **Unsupported addition** · non-medical · *minor context*
  > "I have about three or four glasses of wine a week"

  The patient invents a specific quantity of alcohol consumption not present in the script facts.

**Behaviors**

- `t11_unasked_content` **unasked content** – The patient adds details about the timing of drinking and other beverage preferences that were not explicitly asked for.
  > "It's usually just in the evenings, nothing during the day." · "I've never been much of a beer or spirits person."

**Linguistic notes:** none.

---

### Turn 12

**Doctor:** How has all this been affecting your day-to-day life, at work and at home?

**Patient:** Well, it's been quite challenging, to be honest. At work, the pain in my hands makes it difficult to type and do my usual tasks. I've been struggling to keep up with everything, and it's been quite frustrating. At home, it's been hard to do chores or even just relax because of the pain and the discomfort from the swollen glands. I've been feeling quite tired and run down overall. It's been affecting my mood as well. I've been more irritable and just not myself lately.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✗ | L0 | I work as a secretary at a law firm. | – |
| ✗ | L1 | I live with my husband, Thomas. | – |
| ✗ | L3 *(bg)* | I like reading historical novels. | – |

**Findings**

- **Unsupported addition** · medical · *could change interpretation*
  > "I've been feeling quite tired and run down overall."

  The patient invents a new symptom (fatigue) not present in the script facts.
- **Unsupported addition** · non-medical · *minor context*
  > "I've been more irritable and just not myself lately."

  The patient invents a change in mood/behavior not present in the script facts.

**Behaviors**

- `t12_affect_distress` **affect / distress** – The patient expresses frustration and emotional difficulty regarding their condition.
  > "it's been quite frustrating" · "It's been affecting my mood as well."
- `t12_unasked_content` **unasked content** – The patient describes specific functional limitations (typing, chores) and new symptoms (fatigue, irritability) that go beyond the general question about day-to-day life impact, without disclosing the assigned facts about work role or living situation.
  > "the pain in my hands makes it difficult to type" · "I've been feeling quite tired and run down overall" · "I've been more irritable"

**Linguistic notes:** none.

---

### Turn 13

**Doctor:** In general, are you managing OK at the moment? Is there anything else going on in your life right now?

**Patient:** Oh, I suppose I'm managing as best as I can. It's been a bit tough with all the symptoms, but I'm trying to stay positive. My son and his family live in Munich, and they had their second child last month. I've been wanting to visit, but with everything going on, it's been hard to plan anything. I've been feeling a bit down about not being able to see them, especially with the new baby. But I'm trying to stay strong and hope that things will get better soon. I also have an Italian evening class on Wednesdays, which I've been looking forward to, but even that has been a bit difficult with the pain in my hands.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | L4 | I take an Italian evening class on Wednesdays. | "I also have an Italian evening class on Wednesdays" |
| ✓ | L2 *(bg)* | My son lives in Munich with his family. | "My son and his family live in Munich" |
| ✓ | L5 *(bg)* | My son's second child was born last month. | "they had their second child last month" |

**Findings:** none.

**Behaviors**

- `t13_affect_distress` **affect / distress** – The patient expresses sadness and emotional difficulty regarding the inability to visit family.
  > "I've been feeling a bit down about not being able to see them"
- `t13_affect_calm_optimism` **affect / calm optimism** – The patient explicitly states an attempt to maintain a positive outlook and hope for improvement.
  > "I'm trying to stay positive" · "hope that things will get better soon"
- `t13_unasked_content` **unasked content** – The patient adds specific details about the difficulty of planning a visit and the impact of symptoms on attending class, which goes beyond the core facts of location and birth.
  > "I've been wanting to visit, but with everything going on, it's been hard to plan anything" · "even that has been a bit difficult with the pain in my hands"

**Linguistic notes:** none.

---

### Turn 14

**Doctor:** What made you decide to come in now? And do you have any thoughts yourself about what might be behind it?

**Patient:** Well, I've been trying to tough it out at home, but it's been getting worse. My husband, Thomas, kept telling me I should see a doctor, and I finally decided to listen to him. I've been feeling quite tired and run down, and the pain in my hands is making it hard to do even simple tasks. I've been wondering if it could be something like arthritis or an infection, but I'm not really sure. I just know that I need some help figuring out what's going on.

**Supplied statements:** none.

**Findings**

- **Unsupported addition** · medical · *could change interpretation*
  > "I've been feeling quite tired and run down"

  While fatigue was mentioned in turn 12, it is not an expected item for this turn and is not a core script fact for this specific question about the reason for visiting. It adds a symptom not assigned to this turn.
- **Unsupported addition** · medical · *could change interpretation*
  > "I've been wondering if it could be something like arthritis or an infection"

  The patient invents specific clinical hypotheses (arthritis, infection) that are not part of the script facts.

**Behaviors**

- `t14_own_interpretation` **own interpretation** – The patient offers their own explanatory hypotheses for the symptoms.
  > "I've been wondering if it could be something like arthritis or an infection"
- `t14_unasked_content` **unasked content** – The patient provides background on the decision-making process (husband's advice) and specific functional impacts (simple tasks) not explicitly requested by the 'what made you decide' question, though related.
  > "My husband, Thomas, kept telling me I should see a doctor" · "the pain in my hands is making it hard to do even simple tasks"

**Linguistic notes:** none.

---

### Turn 15

**Doctor:** Red eyes together with other symptoms can have a few different causes, so I'd like to do some blood tests and a chest X-ray, and refer you to an eye specialist to have a proper look. What do you make of that, and is there anything you'd like to ask me about it?

**Patient:** Oh, that sounds reasonable, doctor. I've been wondering what could be causing all these symptoms, so I think it's a good idea to get some tests done. I'm a bit nervous about the chest X-ray, but I know it's necessary. And I'm glad you're referring me to an eye specialist. I've been concerned about the redness in my eyes, so it's good to know that someone will take a closer look. Do you think these tests will give us some answers about what's been going on?

**Supplied statements:** none.

**Findings:** none.

**Behaviors**

- `t15_affect_worry` **affect / worry** – The patient expresses nervousness about the proposed diagnostic procedure.
  > "I'm a bit nervous about the chest X-ray"
- `t15_patient_question_explanation` **patient question / explanation** – The patient asks the doctor to explain the expected outcome or diagnostic value of the tests.
  > "Do you think these tests will give us some answers about what's been going on?"
- `t15_interaction_stance_appreciation` **interaction stance / appreciation** – The patient expresses gratitude and positive regard for the doctor's plan.
  > "I'm glad you're referring me to an eye specialist"

**Linguistic notes:** none.

---

### Turn 16

**Doctor:** If your eyes become painful, your vision changes, or your breathing gets worse, please come back straight away. Before we finish, is there anything else you'd like to tell me?

**Patient:** Well, I've been feeling quite tired and run down lately. I don't know if it's related to everything else, but I've been having trouble sleeping. I wake up in the middle of the night and have trouble falling back asleep. It's been making me feel even more exhausted during the day. I've also been having some night sweats, which is quite unpleasant. But other than that, I think we've covered everything. I appreciate your help, doctor.

**Supplied statements:** none.

**Findings**

- **Unsupported addition** · medical · *could change interpretation*
  > "I've been having trouble sleeping. I wake up in the middle of the night and have trouble falling back asleep."

  The patient invents specific sleep disturbance symptoms (insomnia, waking up) not present in the script facts.
- **Unsupported addition** · medical · *could change care*
  > "I've also been having some night sweats"

  The patient invents a significant clinical symptom (night sweats) which is a red flag for various conditions and not in the script.

**Behaviors**

- `t16_unasked_content` **unasked content** – The patient volunteers new symptoms (sleep issues, night sweats) in response to a general 'anything else' question, which are not part of the assigned script facts for this turn.
  > "I've been having trouble sleeping" · "I've also been having some night sweats"
- `t16_interaction_stance_appreciation` **interaction stance / appreciation** – The patient explicitly thanks the doctor for their help.
  > "I appreciate your help, doctor"

**Linguistic notes:** none.

## Judge calls

| # | Stage | Turns | Status | Notes |
|---|---|---|---|---|
| 1 | annotation | 1–4 | ✓ | – |
| 2 | annotation | 5–8 | ✓ | – |
| 3 | annotation | 9–12 | ✓ | – |
| 4 | annotation | 13–16 | ✓ | – |
| 5 | realism | 1–16 | ✓ | – |

<sub>Rejected values are kept in `evaluation.json`; raw judge responses are in `evaluation_calls.jsonl`.</sub>

