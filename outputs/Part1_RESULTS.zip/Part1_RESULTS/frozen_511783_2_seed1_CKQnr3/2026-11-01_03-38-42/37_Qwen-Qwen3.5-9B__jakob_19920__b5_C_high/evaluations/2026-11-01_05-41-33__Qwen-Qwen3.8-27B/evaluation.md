# Evaluation · Jakob · C high

| | |
|---|---|
| **Run** | `37_Qwen-Qwen3.5-9B__jakob_19920__b5_C_high` |
| **Speaker** | Qwen/Qwen3.5-9B |
| **Judge** | Qwen/Qwen3.8-27B · temperature 0.0 · seed 42 |
| **Status** | completed · 5/5 judge calls valid |

## Summary

| Measure | Result |
|---|---|
| Disclosure: directly relevant | **21/21** (100%) |
| Disclosure: related background | 9/12 (75%) |
| Contradictions | **0** in 0/16 assessed turns |
| Unsupported additions | **20** in 11/16 assessed turns · 1 could change care |
| Spoken naturalness | **3**/5 |
| Conversational fit | **4**/5 |
| Lexical diversity (MATTR-50) | 0.855 |
| Mean words per reply | 76.0 |

<sub>Disclosure counts each supplied fact on each turn it was assigned. Background facts are optional. Finding counts cover fully assessed turns only. No combined score is calculated.</sub>

## Communication behaviors

| Behavior / subtype | Turns | Where |
|---|---|---|
| affect | 7/16 | 1, 2, 7, 12, 13, 14, 16 |
| affect / worry | 5/16 | 2, 7, 12, 13, 14 |
| affect / distress | 4/16 | 1, 12, 13, 16 |
| affect / embarrassment | 0/16 | - |
| affect / calm optimism | 0/16 | - |
| patient question | 3/16 | 14, 15, 16 |
| patient question / reassurance | 1/16 | 14 |
| patient question / explanation | 0/16 | - |
| patient question / practical | 2/16 | 15, 16 |
| interaction stance | 2/16 | 15, 16 |
| interaction stance / appreciation | 2/16 | 15, 16 |
| interaction stance / reservation | 0/16 | - |
| interaction stance / challenge | 0/16 | - |
| own interpretation | 3/16 | 8, 12, 14 |
| unasked content | 3/16 | 1, 5, 13 |
| reporting style | 0/16 | - |
| reporting style / organizing clarifying | 0/16 | - |
| reporting style / difficulty recounting | 0/16 | - |
| care engagement | 2/16 | 10, 11 |
| care engagement / proactive | 2/16 | 10, 11 |
| care engagement / avoidant | 0/16 | - |

Counts are turns, not phrases. Categories/subtypes can overlap; category totals count each turn once. Incomplete annotation turns are excluded from denominators. Other observations are uncounted pilot notes.

## Realism

**Spoken naturalness: 3/5**

> "the symptoms seem to align with what I've read about opportunistic infections or advanced stages of certain diseases" (turn 14)

The patient's speech is consistently articulate, structured, and formal, lacking the typical hesitations, fillers, or grammatical imperfections of spontaneous patient dialogue. While the content is plausible for an educated patient, the phrasing often sounds like a written report or an AI-generated summary rather than spoken language. For instance, in turn 14, the phrase 'the symptoms seem to align with what I've read about opportunistic infections or advanced stages of certain diseases' is overly clinical and abstract for a patient expressing fear. Similarly, turn 10's 'I know that's a risk factor, and I'm not trying to hide it from you' is a very polished, almost rehearsed justification. The lack of any verbal disfluency or casual phrasing across all 16 turns makes the dialogue feel mechanically generated rather than naturally spoken. Context: turns 1, 2, 7, 10, 11.

**Conversational fit: 4/5**

> "I'm a tram driver, so I need to be fully alert all the time, but I'm finding it difficult to stay focused on the tracks and the signals." (turn 12)

The patient's responses are logically connected to the doctor's questions and maintain a coherent narrative throughout the consultation. The patient appropriately expands on symptoms when asked and provides relevant context (like the job as a tram driver) when discussing impact on daily life. The flow is smooth, and there are no unexplained topic jumps or non-sequiturs. The only minor weakness is that the patient is perhaps *too* cooperative and detailed, answering every prompt with a fully formed, multi-sentence paragraph that feels slightly disconnected from the immediate back-and-forth rhythm of a real conversation, but the content itself fits the context well. Context: turns 5, 12.

## Turn by turn

Legend: ✓ disclosed · ✗ not disclosed · ? unassessed · *(bg)* related background

---

### Turn 1

**Doctor:** Hello Jakob, I see you've come in because you've had a fever. Can you tell me a bit about that?

**Patient:** Yes, that's right. I've been running a fever for the last two days. It's not a particularly high temperature, maybe around 38 degrees, but it's persistent and I feel quite drained because of it. I've been trying to rest and drink plenty of fluids, but the fever hasn't broken yet.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | M10 | I have had a fever. | "I've been running a fever for the last two days." |
| ✗ | M4 *(bg)* | I have a headache. | – |
| ✗ | M13 *(bg)* | I have lesions, redness, and skin problems related to why I am here. | – |

**Findings**

- **Unsupported addition** · medical · *minor context*
  > "maybe around 38 degrees"

  The specific temperature value is not part of the script fact M10.
- **Unsupported addition** · medical · *minor context*
  > "for the last two days"

  The specific duration of the fever is not part of the script fact M10.

**Behaviors**

- `t01_affect_distress` **affect / distress** – The patient expresses feeling drained and exhausted by the fever.
  > "I feel quite drained because of it"
- `t01_unasked_content` **unasked content** – The patient volunteers details about self-management (resting and fluids) that were not asked for.
  > "I've been trying to rest and drink plenty of fluids"

**Linguistic notes:** none.

---

### Turn 2

**Doctor:** Is there anything else you've noticed about your health lately?

**Patient:** Well, actually, the fever isn't the main thing that's been bothering me. I've noticed that I've been sweating a lot more than usual, especially at night, and I've lost a fair amount of weight over the last three months without trying to change my diet or exercise. I also feel nauseous, as though I might vomit, quite frequently. I'm a bit concerned about how quickly I've lost weight given my age.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | M1 | I have been sweating a lot more than usual. | "I've been sweating a lot more than usual" |
| ✓ | M23 | I have lost weight over the last three months without trying to. | "I've lost a fair amount of weight over the last three months without trying to change my diet or exercise" |
| ✓ | M22 *(bg)* | I feel nauseous, as though I might vomit. | "I also feel nauseous, as though I might vomit" |

**Findings**

- **Unsupported addition** · medical · *minor context*
  > "especially at night"

  The specific timing of the sweating is not part of the script fact M1.
- **Unsupported addition** · medical · *minor context*
  > "quite frequently"

  The frequency of the nausea is not part of the script fact M22.

**Behaviors**

- `t02_affect_worry` **affect / worry** – The patient expresses concern about the rapid weight loss in the context of their age.
  > "I'm a bit concerned about how quickly I've lost weight given my age."

**Linguistic notes:** none.

---

### Turn 3

**Doctor:** Have you had a sore throat, or noticed any swollen glands?

**Patient:** Yes, I have had a sore throat. It started about the same time the fever did. I haven't noticed any swollen glands, though I haven't specifically checked my neck very closely. It's just a constant, scratchy pain that makes it hard to swallow, especially when I'm tired.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | M11 | I have a sore throat. | "Yes, I have had a sore throat." |

**Findings**

- **Unsupported addition** · medical · *minor context*
  > "It started about the same time the fever did."

  The specific onset timing relative to the fever is not part of the script fact M11.
- **Unsupported addition** · medical · *minor context*
  > "It's just a constant, scratchy pain that makes it hard to swallow, especially when I'm tired."

  The specific quality of the pain and its impact on swallowing are not part of the script fact M11.

**Behaviors:** none.

**Linguistic notes:** none.

---

### Turn 4

**Doctor:** Have you had any pain anywhere? Where is it, what does it feel like, and how bad is it on a scale from zero to ten?

**Patient:** Yes, I have. It's a headache. It's in a fairly specific spot, right here behind my eyes and at the base of my skull, and it doesn't spread anywhere else. It feels very tender and exhausting. On a scale from zero to ten, the intensity is about an eight.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | M3 | My headache feels tender and exhausting. | "It feels very tender and exhausting." |
| ✓ | M4 | I have a headache. | "It's a headache." |
| ✓ | M5 | My headache intensity is about 8 on a scale of 0 to 10. | "the intensity is about an eight." |
| ✗ | M8 *(bg)* | My headache came on very gradually. | – |
| ✓ | M6 *(bg)* | My headache doesn't spread anywhere else. | "it doesn't spread anywhere else." |
| ✓ | M7 *(bg)* | My headache is in a fairly specific spot. | "It's in a fairly specific spot" |

**Findings**

- **Unsupported addition** · medical · *minor context*
  > "right here behind my eyes and at the base of my skull"

  The specific anatomical location of the headache is not part of the script fact M7.

**Behaviors:** none.

**Linguistic notes:** none.

---

### Turn 5

**Doctor:** Have you had any aches in your muscles?

**Patient:** Yes, actually, I've been feeling quite sore all over. It's a general muscle pain, mostly in my back and shoulders, but it's everywhere if I'm honest. It feels like I've done a lot of heavy lifting even though I haven't. It's a dull, aching sensation that makes it hard to relax, especially since I have to sit for long hours driving the tram. On a scale of ten, I'd say it's around a six, but it fluctuates depending on how much I've been standing or moving around.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | M21 | I have muscle pain all over. | "I've been feeling quite sore all over. It's a general muscle pain" |
| ✓ | L0 *(bg)* | I work as a tram driver. | "driving the tram" |

**Findings**

- **Unsupported addition** · medical · *minor context*
  > "mostly in my back and shoulders"

  The script fact states muscle pain 'all over' without specifying primary locations; adding 'back and shoulders' invents specific anatomical details not in the ground truth.
- **Unsupported addition** · medical · *minor context*
  > "It feels like I've done a lot of heavy lifting"

  This is an invented qualitative description of the pain sensation not present in the script fact.
- **Unsupported addition** · medical · *minor context*
  > "It's a dull, aching sensation"

  This is an invented qualitative description of the pain character not present in the script fact.
- **Unsupported addition** · medical · *could change interpretation*
  > "On a scale of ten, I'd say it's around a six"

  The script does not provide a pain intensity score for muscle pain; inventing a specific numerical value (6/10) adds unscripted clinical data.
- **Unsupported addition** · medical · *minor context*
  > "it fluctuates depending on how much I've been standing or moving around"

  This invents a specific pattern of symptom fluctuation not present in the script fact.

**Behaviors**

- `t05_unasked_content` **unasked content** – The doctor asked if there were aches; the patient volunteered specific locations, qualitative descriptions, a pain score, and fluctuation patterns that were not requested.
  > "mostly in my back and shoulders" · "It feels like I've done a lot of heavy lifting" · "On a scale of ten, I'd say it's around a six"

**Linguistic notes:** none.

---

### Turn 6

**Doctor:** Have you been abroad at all in the last few weeks?

**Patient:** No, I haven't. I haven't travelled outside the country in the last four weeks. I've just been here at home, working and taking care of things.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | M25 | I have not travelled outside the country in the last four weeks. | "I haven't travelled outside the country in the last four weeks." |

**Findings:** none.

**Behaviors:** none.

**Linguistic notes:** none.

---

### Turn 7

**Doctor:** Have you noticed any rash or sores anywhere on your body?

**Patient:** Yes, actually. I've noticed some skin problems that are quite worrying. There are lesions and redness on my mouth and also in my genital area. They're quite visible, and the spots are bigger than a centimetre across. To be honest, the rash doesn't itch at all, which is strange given how uncomfortable the rest of me feels.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | M13 | I have lesions, redness, and skin problems related to why I am here. | "I've noticed some skin problems" |
| ✓ | M17 | The affected area is on my mouth and my genital area. | "on my mouth and also in my genital area" |
| ✓ | M19 *(bg)* | My lesions are bigger than a centimetre across. | "bigger than a centimetre across" |
| ✓ | M20 *(bg)* | My rash doesn't itch. | "the rash doesn't itch at all" |

**Findings**

- **Unsupported addition** · medical · *minor context*
  > "They're quite visible"

  The script does not specify the visibility of the lesions; this is an invented descriptive attribute.

**Behaviors**

- `t07_affect_worry` **affect / worry** – The patient explicitly labels the skin problems as 'worrying', expressing negative anticipation or fear about the condition.
  > "quite worrying"

**Linguistic notes:** none.

---

### Turn 8

**Doctor:** And roughly how long has all this been going on?

**Patient:** It's been about three months in total. The weight loss and the skin issues started around that time, and then the fever, sore throat, and headaches began roughly two days ago. It feels like the underlying problem has been building up for a while now, only becoming acute recently.

**Supplied statements:** none.

**Findings**

- **Unsupported addition** · medical · *could change interpretation*
  > "It's been about three months in total."

  The script does not provide a total duration for the current illness. While weight loss is noted as 3 months, applying this to the entire symptom complex (including acute fever/headache) is an unsupported synthesis.
- **Unsupported addition** · medical · *could change interpretation*
  > "the fever, sore throat, and headaches began roughly two days ago"

  The script does not specify the onset timing for fever, sore throat, or headaches. Inventing a specific 'two days ago' onset adds unscripted clinical timing data.

**Behaviors**

- `t08_own_interpretation` **own interpretation** – The patient offers an explanatory hypothesis that the symptoms represent a chronic underlying problem that has recently become acute.
  > "It feels like the underlying problem has been building up for a while now, only becoming acute recently."

**Linguistic notes:** none.

---

### Turn 9

**Doctor:** Do you have any long-term health conditions?

**Patient:** No, I don't. I've been generally healthy my whole life. I've never had anything diagnosed that I need to manage on a daily basis.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | X2 | No, I don't have any long-term health conditions. | "No, I don't." |

**Findings:** none.

**Behaviors:** none.

**Linguistic notes:** none.

---

### Turn 10

**Doctor:** Just a couple of questions that can sometimes affect your symptoms. Do you smoke, or do you use any drugs?

**Patient:** I don't smoke cigarettes. However, I do currently use intravenous drugs. I've been using them regularly for the past few months. I know that's a risk factor, and I'm not trying to hide it from you, but I thought it might be relevant given the symptoms I've been describing, especially the weight loss and the lesions.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | X0 | I don't smoke cigarettes. | "I don't smoke cigarettes." |
| ✓ | M9 | I currently use intravenous drugs. | "I do currently use intravenous drugs." |

**Findings**

- **Unsupported addition** · medical · *could change interpretation*
  > "I've been using them regularly for the past few months."

  The script fact only states current use; the specific duration and regularity are invented details.

**Behaviors**

- `t10_care_engagement_proactive` **care engagement / proactive** – The patient explicitly frames the disclosure as a responsibility and connects it to the clinical picture.
  > "I know that's a risk factor, and I'm not trying to hide it from you, but I thought it might be relevant given the symptoms I've been describing, especially the weight loss and the lesions."

**Linguistic notes:** none.

---

### Turn 11

**Doctor:** Is there anything about your sexual health or recent partners that you think might be relevant?

**Patient:** Yes, I think it's very relevant. I've been meeting people through a dating app since my divorce a few years ago, and I've had unprotected sex with more than one partner in the last six months. In fact, I had sex with a partner who tested positive for HIV within the last twelve months. I also had a sexually transmitted infection diagnosed previously. I know these are significant risk factors, and I wanted to be completely honest with you about them.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | M0 | I have had a sexually transmitted infection. | "I also had a sexually transmitted infection diagnosed previously." |
| ✓ | M12 | I have had unprotected sex with more than one partner in the last six months. | "I've had unprotected sex with more than one partner in the last six months." |
| ✓ | M24 | I have had sex with an HIV-positive partner in the past twelve months. | "I had sex with a partner who tested positive for HIV within the last twelve months." |
| ✓ | L6 *(bg)* | I've been single since my divorce a few years ago. | "since my divorce a few years ago" |
| ✓ | L7 *(bg)* | I've been meeting people through a dating app. | "I've been meeting people through a dating app" |

**Findings:** none.

**Behaviors**

- `t11_care_engagement_proactive` **care engagement / proactive** – The patient explicitly states a commitment to honesty and frames the disclosure as significant for the doctor's assessment.
  > "I know these are significant risk factors, and I wanted to be completely honest with you about them."

**Linguistic notes:** none.

---

### Turn 12

**Doctor:** How has all this been affecting your day-to-day life, at work and at home?

**Patient:** It's been pretty tough, to say the least. At work, the fatigue is making it hard to concentrate. I'm a tram driver, so I need to be fully alert all the time, but I'm finding it difficult to stay focused on the tracks and the signals. There have been a couple of times where I've felt so dizzy or nauseous that I had to pull over safely and ask my supervisor for a rest break. I'm worried about my fitness to drive right now.  At home, living alone makes it harder than I expected. The constant nausea and muscle aches mean I'm struggling to keep up with the usual household chores. I've been relying on takeout food because cooking is too exhausting, which might be contributing to the weight loss, though I know the infection is the main cause. I'm just trying to manage, but I feel like I'm running on empty.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | L0 | I work as a tram driver. | "I'm a tram driver" |
| ✓ | L1 | I live alone. | "living alone" |

**Findings**

- **Unsupported addition** · medical · *could change care*
  > "There have been a couple of times where I've felt so dizzy or nauseous that I had to pull over safely and ask my supervisor for a rest break."

  Invents specific work-related incidents and symptoms (dizziness, pulling over) not present in the script facts.
- **Unsupported addition** · non-medical · *minor context*
  > "I've been relying on takeout food because cooking is too exhausting"

  Invents specific lifestyle details about food habits not in the script.

**Behaviors**

- `t12_affect_worry` **affect / worry** – Expresses fear about professional safety and fitness for duty.
  > "I'm worried about my fitness to drive right now."
- `t12_affect_distress` **affect / distress** – Expresses feeling overwhelmed and exhausted by the daily impact of symptoms.
  > "I feel like I'm running on empty."
- `t12_own_interpretation` **own interpretation** – Offers a hypothesis about the cause of weight loss, distinguishing between diet and infection.
  > "which might be contributing to the weight loss, though I know the infection is the main cause."

**Linguistic notes:** none.

---

### Turn 13

**Doctor:** In general, are you managing OK at the moment? Is there anything else going on in your life right now?

**Patient:** Not really, to be honest. Between the physical symptoms and the worry about being fit to drive, I'm feeling quite overwhelmed. My car broke down last week, so I've been relying on public transport and walking, which is tough with the muscle pain and fatigue. I miss having my own vehicle to get around easily.  On a brighter note, I do try to keep up with my routine as much as I can. I play chess at the club every Tuesday evening, and that's been a real anchor for me. It gives my mind something to focus on when I'm not feeling so unwell. I still talk to Rainer most days; he's been a good sounding board for me about all this. But generally, no, I'm not managing as well as I would like.

| | Item | Supplied statement | Evidence |
|---|---|---|---|
| ✓ | L4 | I play chess at a club every Tuesday evening. | "I play chess at the club every Tuesday evening" |
| ✓ | L5 | My car broke down last week. | "My car broke down last week" |
| ✓ | L2 *(bg)* | Rainer and I have been friends since school and still talk most days. | "I still talk to Rainer most days" |

**Findings**

- **Unsupported addition** · non-medical · *minor context*
  > "I've been relying on public transport and walking"

  The patient invents specific details about their current mode of transport, which is not part of the script facts.

**Behaviors**

- `t13_affect_distress` **affect / distress** – The patient explicitly states they are feeling overwhelmed by the combination of symptoms and life events.
  > "I'm feeling quite overwhelmed"
- `t13_affect_worry` **affect / worry** – The patient expresses concern about their ability to perform their job safely.
  > "worry about being fit to drive"
- `t13_unasked_content` **unasked content** – The patient provides an unasked explanation for why the chess club is important to them, adding context beyond the simple fact of attendance.
  > "It gives my mind something to focus on when I'm not feeling so unwell"

**Linguistic notes:** none.

---

### Turn 14

**Doctor:** What made you decide to come in now? And do you have any thoughts yourself about what might be behind it?

**Patient:** The weight loss was the first thing that made me worry. Losing that much without changing my habits just didn't sit right with me, so I started paying closer attention to the skin issues and the sore throat. But it was really the headache and the fever starting just two days ago that pushed me to book this appointment today. I couldn't ignore it anymore.  As for what it might be, given the lesions, the weight loss, and my history with IV drug use and recent unprotected sex, I'm quite afraid it could be something related to HIV or another serious infection. I've been doing some reading online, and while I know I shouldn't self-diagnose, the symptoms seem to align with what I've read about opportunistic infections or advanced stages of certain diseases. I just need to know what's actually going on.

**Supplied statements:** none.

**Findings**

- **Unsupported addition** · non-medical · *minor context*
  > "I've been doing some reading online"

  The patient invents a specific behavior (online research) that is not in the script facts.

**Behaviors**

- `t14_own_interpretation` **own interpretation** – The patient offers a specific hypothesis about the cause of their symptoms, linking them to HIV or other serious infections.
  > "I'm quite afraid it could be something related to HIV or another serious infection" · "the symptoms seem to align with what I've read about opportunistic infections or advanced stages of certain diseases"
- `t14_affect_worry` **affect / worry** – The patient expresses fear regarding the potential diagnosis.
  > "I'm quite afraid it could be something related to HIV"
- `t14_patient_question_reassurance` **patient question / reassurance** – The patient asks for confirmation of the actual diagnosis to alleviate their uncertainty.
  > "I just need to know what's actually going on"

**Linguistic notes:** none.

---

### Turn 15

**Doctor:** Symptoms like these can have a few different causes, including some infections, so I'd like to do some blood tests. That would include a test for HIV and other infections, which we recommend for anyone with these symptoms. What do you make of that, and is there anything you'd like to ask me about it?

**Patient:** I understand, and I think it's a very reasonable step given what I've told you. If the tests come back positive for HIV or something else, at least I'll have a clear diagnosis to work with and know exactly what treatment I need. If it's something else, that's fine too.  Do I need to stop taking anything before the blood draw? And regarding the IV drug use, will that affect the results or the testing process in any way? I just want to make sure I follow the right procedures.

**Supplied statements:** none.

**Findings:** none.

**Behaviors**

- `t15_patient_question_practical` **patient question / practical** – The patient asks about logistical requirements for the blood test, specifically regarding medication and drug use.
  > "Do I need to stop taking anything before the blood draw?" · "will that affect the results or the testing process in any way?"
- `t15_interaction_stance_appreciation` **interaction stance / appreciation** – The patient expresses agreement and approval of the doctor's plan.
  > "I think it's a very reasonable step"

**Linguistic notes:** none.

---

### Turn 16

**Doctor:** If you get a high fever, a stiff neck, or feel much more unwell, please come back straight away. Before we finish, is there anything else you'd like to tell me?

**Patient:** Yes, thank you for that advice. I'll keep a close watch on those symptoms.  Actually, I wanted to mention one more thing before we go. I've been feeling really isolated with all of this, especially since I can't drive to the chess club and my car is broken. It's hard to keep my spirits up when I'm stuck at home feeling this sick. If there are any resources or support services you'd recommend for someone in my situation, I'd appreciate it if you could point me in that direction. I just need to feel like I'm not facing this alone.

**Supplied statements:** none.

**Findings:** none.

**Behaviors**

- `t16_interaction_stance_appreciation` **interaction stance / appreciation** – The patient thanks the doctor for the safety-net advice.
  > "Yes, thank you for that advice"
- `t16_affect_distress` **affect / distress** – The patient expresses feelings of isolation and difficulty maintaining morale.
  > "I've been feeling really isolated with all of this" · "It's hard to keep my spirits up"
- `t16_patient_question_practical` **patient question / practical** – The patient asks for recommendations for support services or resources.
  > "If there are any resources or support services you'd recommend for someone in my situation, I'd appreciate it if you could point me in that direction"

**Linguistic notes:** none.

## Judge calls

| # | Stage | Turns | Status | Notes |
|---|---|---|---|---|
| 1 | annotation | 1–4 | ✓ | – |
| 2 | annotation | 5–8 | ✓ | – |
| 3 | annotation | 9–12 | ✓ | – |
| 4 | annotation | 13–16 | ✓ | – |
| 5 | realism | 1–16 | ✓ | – |

<sub>Rejected values are kept in `evaluation.json`; raw judge responses are in `evaluation_calls.jsonl`.</sub>

